from django.http import HttpResponse
from django.shortcuts import render
from cap.models import User
from django.contrib import auth

def index(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = auth.authenticate(email=email,password=password)
        if user is not None:
            auth.login(request,user)
            user=request.user
            print("login success")
            return render(request,'home.html')
        else:
            print("invalid inputs")
            return render(request,'index.html')

    return render(request, 'index.html')

def signup(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        c_password = request.POST['c_password']

        if password == c_password:
            if User.objects.filter(email=email).exists():
                print("already exist")
                return render(request,'index.html')
            else:
                user = User.objects.create_user(email=email,password=password)
                user.save()
                print("Account Created")
                return render(request,'index.html')
    return render(request,'signup.html')


def market(request):
    return render(request,'market.html')

def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

